//Made by : Hadi Mustafa
//Matric.num: 92547995
package containers;

public abstract class Container {
	
	private double height;
	private double width;
	private double length;
	private double volume;
	private int numberofContainers;
	
	public Container() {
		this.numberofContainers = 0;
	}
	

	
	public void height_setter(double height) {
		this.height = height;
	}
	
	public void width_setter(double width) {
		this.width = width;
	}
	
	public void lenght_setter(double length) {
		this.length = length;
	}
	
	public void numberofContainers_setter(int quantity) {
		this.numberofContainers += quantity;
	}
	
	
	
	
	public double height_getter() {
		return this.height;
	}
	
	public double width_getter() {
		return this.width;
	}
	
	public double length_getter() {
		return this.length;
	}
	
	public double volume_getter() {
		return this.volume;
	}
	
	public int numberofContainers_getter() {
		return this.numberofContainers;
	}
	
	
	
	
	public abstract void printContainerInfo();
	
	public void volume() {
		this.volume = this.height*this.length*this.width;
	}

}
