//Made by : Hadi Mustafa
//Matric.num: 92547995
package containers;

public class SmallContainer extends Container{
	
	private int price;
	public SmallContainer() {
		
		super.height_setter(2.59);
		super.lenght_setter(6.06);
		super.width_setter(2.43);
		
		super.volume();
	}
	
	
	
	public void price_setter(double weight) {
		if(weight <= 500) {
			this.price = 1000;
		}else {
			this.price = 1200;
		}
	}
	
	
	
	public int price_getter() {
		return this.price;
	}
	
	
	
	//methods
	
	public void printContainerInfo() {
		
		String containerInfo = "";
		
		
		containerInfo += "Container Type: Small Container\n";
		containerInfo += "Container Price if weight <=500 : 1000� / 1070$ "+"\n";
		containerInfo += "Container Price if weight > 500 : 1200� / 1284$"+"\n";
		containerInfo += "Container Height: " + Double.toString(super.height_getter())+ "m"  +"\n";
		containerInfo += "Container Length: " + Double.toString(super.length_getter())+ "m"  +"\n";
		containerInfo += "Container Width: " + Double.toString(super.width_getter()) + "m" +"\n";
		containerInfo += "Container Volume: "+ String.format("%.2f" ,(super.volume_getter())) + "m3"+ "\n";
		
		
		System.out.println(containerInfo);
		
	}

}