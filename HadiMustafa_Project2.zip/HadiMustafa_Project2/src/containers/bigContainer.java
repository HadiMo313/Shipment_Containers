//Made by : Hadi Mustafa
//Matric.num: 92547995
package containers;

public class bigContainer extends Container{

	private int price;
	
	public bigContainer() {
		
		super.height_setter(2.59);
		super.lenght_setter(12.01);
		super.width_setter(2.43);
		this.price = 1800;
		
		super.volume();
	}
	
	// getters
	
	public int price_getter() {
		return this.price;
	}
	
	
	//methods
	
	public void printContainerInfo() {
		
		String containerInfo = "";
		
	
		
		containerInfo += "Container Type: Big Container\n";
		containerInfo += "Container Price: " + Integer.toString(this.price)+ " / 1926$ "+"\n";
		containerInfo += "Container Height: " + Double.toString(super.height_getter())  + "m"+"\n";
		containerInfo += "Container Length: " + Double.toString(super.length_getter()) + "m" +"\n";
		containerInfo += "Container Width: " + Double.toString(super.width_getter())  + "m"+"\n";
		containerInfo += "Container Volume: "+String.format("%.2f" ,(super.volume_getter())) + "m3"+ "\n";
		
		containerInfo += "\n";
		
	
		System.out.println(containerInfo);
	}	
	}