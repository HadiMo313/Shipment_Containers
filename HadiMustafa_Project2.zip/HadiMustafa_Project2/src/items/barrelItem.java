//Made by : Hadi Mustafa
//Matric.num: 92547995
package items;

import java.util.Scanner;


	public class barrelItem extends Item{
		
		private double radius1;
		private double radius2;
		private double height;
		
		public barrelItem(){
			Scanner scanner = new Scanner(System.in);
			
			// input barrel dimension value
			System.out.print("Enter height: ");
			this.height = scanner.nextDouble();
			
			System.out.print("Enter First radius: ");
			this.radius1 = scanner.nextDouble();
			
			System.out.print("Enter Second radius: ");
			this.radius2 = scanner.nextDouble();
			
			this.volume();
			
			
		}
		
		public void volume() {
			
			super.volume_setter(this.height*3.14*( 2*this.radius1 *2*this.radius1 
					+ this.radius2*this.radius2) / 3);

			super.total_volume();
		}
	}

