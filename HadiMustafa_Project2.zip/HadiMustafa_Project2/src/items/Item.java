//Made by : Hadi Mustafa
//Matric.num: 92547995
package items;

import java.util.Scanner;


	public abstract class Item {
		
		private String name; 
		private double weight;
		private double total_weight;
		private int quantity;
		private double volume;
		private double total_volume;
		
		
	     
		
		public Item(){
			Scanner scanner = new Scanner(System.in);
			
			// User should enter the name
			System.out.println("\n Laptop     Mouse      Desktop      LCD ");
		    
			
			System.out.print("Enter Product:");
			
			this.name = scanner.next();
			
			// User should enter the quantity
			System.out.print("Enter Quantity: ");
			this.quantity = scanner.nextInt();
		
			//   User should enter the weight
			System.out.print("Enter Weight(kg):");
			this.weight = scanner.nextDouble();
			
			this.total_weight = this.weight * this.quantity;
			
			
		}
		
		// setters 
		
		public void quantity_setter(int quantity) {
			this.quantity = quantity;
		}
		public void volume_setter(double volume) {
			this.volume = volume;
		}
		// getters
		
		public String name_getter() {
			return this.name;
		}
		
		public double weight_getter() {
			return this.weight;
		}
		
		public double total_weight_getter() {
			return this.total_weight;
		}
		
		public int quantity_getter() {
			return this.quantity;
		}
		
		public double volume_getter() {
			return this.volume;
		}
		
		public double total_volume_getter() {
			return this.total_volume;
		}
		
		//methods
		
		public abstract void volume();
		
		
		public void total_volume() {
			this.total_volume = this.volume*this.quantity;
		}
	}


