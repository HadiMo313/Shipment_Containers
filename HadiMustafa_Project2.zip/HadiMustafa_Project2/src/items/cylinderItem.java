//Made by : Hadi Mustafa
//Matric.num: 92547995
package items;

import java.util.Scanner;


	public class cylinderItem extends Item{
		
		private double radius;
		private double height;
		
		public cylinderItem(){
			Scanner scanner = new Scanner(System.in);
			
			// input cylinder  dimentions
			System.out.print("Enter radius: ");
			this.radius = scanner.nextDouble();
			System.out.print("Enter height: ");
			this.height = scanner.nextDouble();
			
			this.volume();
			
			
		}

		
		public void volume() {
			
			super.volume_setter(Math.PI*Math.pow(this.radius, 2)*this.height);
			super.total_volume();
			
		}
}
