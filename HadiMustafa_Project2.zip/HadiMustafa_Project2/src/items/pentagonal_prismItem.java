//Made by : Hadi Mustafa
//Matric.num: 92547995
package items;

import java.util.Scanner;


	public class pentagonal_prismItem extends Item{

		private double length;
		private double height;
		private double apothem;
		public pentagonal_prismItem(){
			
			Scanner scanner = new Scanner(System.in);
			
			// input pentgon's dimensions
			System.out.print("Enter apothem: ");
			this.apothem = scanner.nextDouble();
			
			System.out.print("Enter height: ");
			this.height = scanner.nextDouble();
			
			System.out.print("Enter length: ");
			this.length = scanner.nextDouble();
			
			
			this.volume();
			
			
		}
		
		public void volume() {
			
			super.volume_setter(5/2*this.apothem*this.height*this.length);
			super.total_volume();
		}
		



}
