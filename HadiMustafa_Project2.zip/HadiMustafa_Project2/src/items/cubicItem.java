//Made by : Hadi Mustafa
//Matric.num: 92547995
package items;

import java.util.Scanner;


	public class cubicItem extends Item{

		private double side;
		
		public cubicItem(){
			Scanner scanner = new Scanner(System.in);
			
			// input cubic dimension value
			System.out.print("Enter side: ");
			this.side = scanner.nextDouble();
			
			this.volume();
			
		
		}
		
		public void volume() {
			
			super.volume_setter(this.side*3);
			super.total_volume();
		}
		

	}


