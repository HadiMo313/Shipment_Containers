//Made by : Hadi Mustafa
//Matric.num: 92547995
package methods;

import java.util.ArrayList;
import java.util.Scanner;

import containers.SmallContainer;
import containers.bigContainer;
import items.Item;
import items.barrelItem;
import items.cubicItem;
import items.cylinderItem;
import items.pentagonal_prismItem;

public class Calculation {
	
	private ArrayList<Item> order = new ArrayList<Item>(); // arraylist to store the order
	
	public Calculation() {
}
	// methods to add items to the order arraylist
	public void add_item(Item item) {
		this.order.add(item);
		
		}
	
	// method to create the order to calculate shipping price
	public void add_order() {
		
		Scanner orderScan = new Scanner(System.in);
		
		String boxtype ;
		char add_other;
		
			System.out.println(" Cylinder     Cubic      Pentagonal       Barrel ");
			System.out.print("Select a shape:") ;
			boxtype=orderScan.nextLine().toUpperCase();
		
			if (boxtype.equals("CUBIC")) {
					add_item(new cubicItem());
			
			
		}
	           else if (boxtype.equals("BARREL")) {
					add_item(new barrelItem());
	         
	           }
					else if (boxtype.equals("CYLINDER")) {
					add_item(new cylinderItem());
					
			}
					else if (boxtype.equals("PENTAGONAL")) {
					add_item(new pentagonal_prismItem());
					}
					else {
						System.out.println("Enter one of these shapes:");
					add_order();
					}
		
		System.out.println("Do you want to add another Item? (y) yes (n) No");
			add_other = orderScan.next().toLowerCase().charAt(0);
		if (add_other == 'y') 
			add_order();
	//	}else 
			//System.out.println("Okay");
		
	}
	
	// method to print the information about the order
	public void printOrderInformation() {
		System.out.println(" Name  "+"     Quantity  "+"   Weight" + "        Volume"+"\n");
		for(int i = 0; i<this.order.size(); i++ ) {
					 
			System.out.println( this.order.get(i).name_getter() +"     |   "+ this.order.get(i).quantity_getter() 
					+"      |   " + String.format("%.2f", this.order.get(i).total_weight_getter())+"Kg"+"  |   "+
					String.format("%.2f",this.order.get(i).total_volume_getter())+"m3");
			for(int k=0;k<50;k++) {
				System.out.print("-");
			}
			System.out.println();
		}
	}
	
	
	
	//method to calculate the total volume
	public double total_volume(ArrayList<Item> order) {
		
		double total_volume=0;
		
		for (Item i : order) {
			total_volume += i.total_volume_getter();
		}
		
		return total_volume;
	}
	
	// method to calculate the total weight
	public double total_weight(ArrayList<Item> order) {
		
		double total_weight=0;
		
		for (Item i : order) {
			total_weight += i.total_weight_getter();
		}
		
		return total_weight;
	}
	
	// method to get the price
	public long shipping_price(bigContainer bigcontainer, SmallContainer smallcontainer) {
		
		long shipping_price =0L;
		
		shipping_price = bigcontainer.numberofContainers_getter()*bigcontainer.price_getter() + smallcontainer.numberofContainers_getter()*smallcontainer.price_getter();
		
		return shipping_price;
	}

	
	public void best_shipping() {
		Scanner exchange = new Scanner(System.in);
		bigContainer bigcontainer = new bigContainer();
		SmallContainer smallcontainer = new SmallContainer();
		
		double total_volume = this.total_volume(this.order);
		double total_weight = this.total_weight(this.order);
		
		if(total_volume<=smallcontainer.volume_getter()) {
			smallcontainer.numberofContainers_setter(1);
			smallcontainer.price_setter(total_weight);
			
		}else if (total_volume>=smallcontainer.volume_getter() && total_volume<=bigcontainer.volume_getter()) {
			bigcontainer.numberofContainers_setter(1);
		}else {
			bigcontainer.numberofContainers_setter((int) (total_volume/bigcontainer.volume_getter()));
			
			if((total_volume%bigcontainer.volume_getter())<=smallcontainer.volume_getter()) {
				smallcontainer.numberofContainers_setter(1);
				smallcontainer.price_setter(((total_volume%bigcontainer.volume_getter())/total_volume) * total_weight);
			}else {
				bigcontainer.numberofContainers_setter(1);
			}
		}
	
		
		System.out.print("\n\t\t BEST SHIPPING OPTION\n");
	
		System.out.println("Total Weight: " +String.format("%.2f",total_weight)  +"Kg");
		System.out.println("Total Volume: " + String.format("%.2f",total_volume) +"m3");
		System.out.println( bigcontainer.numberofContainers_getter() + " Big Container(s)" + " & "
		+ smallcontainer.numberofContainers_getter()+ " Small Container(s)");
		
            System.out.println("Total Price(�): " + this.shipping_price(bigcontainer, smallcontainer) + "�");
		System.out.println("Total Price($): " + this.shipping_price(bigcontainer, smallcontainer)*1.07 + "$\n");
	     System.out.println("    ****For Delivery Express Price + 29%****");
		System.out.println("\n\tPress |y| for addding this feature: \t\n");
	     String user=exchange.nextLine().toUpperCase();
		if (user.equals("Y")) {
			System.out.println("You have added the express delivery");
			System.out.print("\n\t\t BEST SHIPPING OPTION\n");
			
			System.out.println("Total Weight: " +String.format("%.2f",total_weight)  +"Kg");
			System.out.println("Total Volume: " + String.format("%.2f",total_volume) +"m3");
			System.out.println( bigcontainer.numberofContainers_getter() + " Big Container(s)" + " & "
			+ smallcontainer.numberofContainers_getter()+ " Small Container(s)");
			long newshippingPrice =(long) ( this.shipping_price(bigcontainer, smallcontainer)*0.29) + this.shipping_price(bigcontainer, smallcontainer);
			
	            System.out.println("Total Price(�): " + newshippingPrice + "�");
			System.out.println("Total Price($): " + String.format("%.2f",newshippingPrice*1.07) + "$");
			
			System.out.println("Thank You!");
	}
		else 
			System.out.println("Thank You!");
		
System.exit(0);
			 
		
	}
}