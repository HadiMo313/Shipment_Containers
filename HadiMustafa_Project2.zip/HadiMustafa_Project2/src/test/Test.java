//Made by : Hadi Mustafa
//Matric.num: 92547995
package test;

import java.util.Scanner;

import containers.SmallContainer;
import containers.bigContainer;
import methods.Calculation;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test  test = new Test();
		
		test.menu();
		
		
	}
	
	public void menu() {
		
		Scanner menuScan = new Scanner(System.in);
		char set = 0;
		System.out.println("\n\tWELCOME TO OUR SHIPMENT\n");
		System.out.println(" 1) Insert Order");
		System.out.println(" 2) Container Information");
		byte choose = menuScan.nextByte();
		
		switch (choose) {
			case 1:
				
				Calculation order = new Calculation();
					
				order.add_order();
				
				subMenu(order);
				
				break;
				
			case 2:
				do {
					System.out.println("\nAbout Which Container do you want information: \n");
					System.out.println("1) Big Container");
					System.out.println("2) Small Container");
					choose = menuScan.nextByte();
				
					switch (choose) {
						case 1:
							bigContainer bigcontainer = new bigContainer();
							bigcontainer.printContainerInfo();
							break;
						case 2:
							SmallContainer smallcontainer = new SmallContainer();
							smallcontainer.printContainerInfo();
							break;
						default:
							System.out.println("Enter a number between 1 and 2");
							break;
					}
					System.out.println("Do you want to return to the previous menu? Y/N");
					set = menuScan.next().toUpperCase().charAt(0);
				}while(set=='N');
				menu();
				break;
			
			default:
				do {
					System.out.println("Please select a valid option.");
					menu();
				}while(set == 'N');
				break;
		}
		
		
	}
	
	
	
	public void subMenu(Calculation order) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("\nPlease select an option: \n");
		System.out.println("1) See order");
		System.out.println("2) Print shipping results");
		System.out.println("3)If you want to cancel the order enter anything else:");

		byte choose = scanner.nextByte();
		
		switch (choose) {
			case 1:
				order.printOrderInformation();
				subMenu(order);
				break;

			case 2:
				order.best_shipping();

		}
	}
	
	

}
